<template>
  <biblioteca-single-content-layout container-size="lg">
    <template v-if="usuario" #content>
      <div v-if="mostrarMensagem" class="success-message">
        Usuário aprovado com sucesso!
      </div>
      <div v-if="mostrarMensagem2" class="danger-message">
        Usuário negado com sucesso!
      </div>
      <biblioteca-row class="d-flex align-items-center">
        <biblioteca-col>
          <biblioteca-header>
            {{ usuario.nome_completo }}
          </biblioteca-header>
        </biblioteca-col>
      </biblioteca-row>
      <biblioteca-row>
        <biblioteca-col>
          <biblioteca-p class="biblioteca-u-text--medium">
            {{ usuario.email }}
          </biblioteca-p>
        </biblioteca-col>
      </biblioteca-row>
      <div>
        <button type="button" class="btn btn-success" @click="saveUsuario()"> Success </button>
        <button type="button" class="btn btn-danger" @click="onDeleteUsuario()">Danger</button>
      </div>
    </template>
  </biblioteca-single-content-layout>
</template>

<script>
import { USUARIO_ERRORS } from '@/modules/usuario/usuario.constants';
// eslint-disable-next-line import/no-cycle
import { goToUsuarioNotFound } from '@/modules/usuario/usuario.routes';
import { toastError } from '@/services/toastService';
import { saveUsuario, getUsuario, removeUsuario } from '@/modules/usuario/usuario.service';
import BibliotecaSingleContentLayout from '@/layouts/SingleContentLayout.vue';

export default {
  name: 'BibliotecaUsuarioViewPage',
  components: {
    BibliotecaSingleContentLayout,
  },
  data() {
    return {
      mostrarMensagem: false,
      mostrarMensagem2: false,
      usuario: null,
    };
  },
  computed: {
    id() {
      return this.$route.params?.id;
    },
  },
  mounted() {
    this.fetch();
  },
  methods: {
    fetch() {
      getUsuario(this.id)
        .then(data => {
          this.usuario = data.data;
        })
        .catch(err => {
          this.usuario = null;
          if (err) {
            goToUsuarioNotFound(this.$router);
          } else if ((err.response.data.errors === USUARIO_ERRORS[err.response.status] && err.response.status === 404)) {
            goToUsuarioNotFound(this.$router);
          } else {
            toastError('Erro ao buscar o usuário');
          }
        });
    },
    saveUsuario() {
      saveUsuario(this.usuario)
        .then(() => {
          this.mostrarMensagem = true;
          setTimeout(() => {
            this.mostrarMensagem = false;
            this.$router.go(-1);
          }, 1000);
        })
        .catch(() => toastError('Erro ao aprovar o usuário'));
    },
    onDeleteUsuario() {
      removeUsuario(this.usuario)
        .then(() => {
          this.mostrarMensagem2 = true;
          setTimeout(() => {
            this.mostrarMensagem2 = false;
            this.$router.go(-1);
          }, 1000);
        })
        .catch(() => toastError('Não foi possível reprovar o usuário'));
    },
  },
};
</script>
<style>
.success-message {
  background-color: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
  padding: 10px;
  margin-top: 10px;
}
.danger-message{
  background-color: #d4edda;
  color: #7e0707;
  border: 1px solid #c3e6cb;
  padding: 10px;
  margin-top: 10px;
}
</style>
