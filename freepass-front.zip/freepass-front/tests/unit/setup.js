import Vue from 'vue';

import './window.mock';

Vue.config.productionTip = false;
